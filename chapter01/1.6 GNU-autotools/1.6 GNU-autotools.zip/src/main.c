#include "head.h"

int main(void)
{
	haircut();
	havemeal();

	return 0;
}
