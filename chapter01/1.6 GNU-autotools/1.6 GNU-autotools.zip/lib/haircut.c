#include "head.h"

void haircut(void)
{
	printf("I have my hair cut.\n");
}
