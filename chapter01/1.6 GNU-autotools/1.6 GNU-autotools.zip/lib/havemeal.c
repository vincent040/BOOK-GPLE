#include "head.h"

void havemeal(void)
{
	printf("I'm having my dinner.\n");
}
